﻿import turtle
def square(pretty_color):
	sides = range(4)
	amy = turtle.Turtle()
	amy.color(pretty_color)
	amy.penup()
	amy.back(200)
	amy.pendown()
	for side in sides:		
		amy.forward(50)
		amy.left(90)
	amy.ht()
def triangle(pretty_color):
	sides = range(3)
	amy = turtle.Turtle()
	amy.color(pretty_color)
	amy.penup()
	amy.back(100)
	amy.pendown()
	for side in sides:		
		amy.forward(70)
		amy.left(120)
	amy.ht()
def free(sides,forward, color, width, speed):	
	amy = turtle.Turtle()
	amy.color(color)
	amy.width(width)
	amy.speed(speed)	
	for side in sides:		
		amy.forward(forward)
		amy.left(360/sides)
	amy.ht()
def robot(pretty_color):
	amy = turtle.Turtle()
	amy.color(pretty_color)
	x = input("Enter Shape's Color ? ")
	pretty_color = x
	start = ""
	start = input("do you want start this app")
	if start == "yes":
		square(x)
	else:
		triangle(x)